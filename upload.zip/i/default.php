<form enctype="multipart/form-data" method="post"action ="file_uploader.php">
Choose your file here:
<input name="file1" type="file" /><br /><br />
<input type="submit" value="Upload It" />
<a href= delete.php>delete all uploads</a>
<br>
<br>