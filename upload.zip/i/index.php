

<form enctype="multipart/form-data" method="post"action ="file_upload_script.php">
Choose your file here:
<input name="file1" type="file" /><br /><br />
<input type="submit" value="Upload It" />

<a href= default.php>For 5000 times upload</a>
<br>
<br>
